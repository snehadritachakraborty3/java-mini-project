package servlet;

import model.Question;
import data.QuestionBank;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/submit")
public class SubmitServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Question> questions = QuestionBank.getQuestions();
        int correct = 0;

        for (int i = 0; i < questions.size(); i++) {
            String ans = req.getParameter("q" + i);
            if (ans != null && Integer.parseInt(ans) == questions.get(i).getCorrectIndex()) {
                correct++;
            }
        }

        int total = questions.size();
        double percent = (correct * 100.0) / total;

        req.setAttribute("correct", correct);
        req.setAttribute("total", total);
        req.setAttribute("percent", percent);

        req.getRequestDispatcher("result.jsp").forward(req, resp);
    }
}
