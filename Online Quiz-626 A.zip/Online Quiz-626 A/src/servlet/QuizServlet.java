package servlet;

import data.QuestionBank;
import model.Question;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/quiz")
public class QuizServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        List<Question> questions = QuestionBank.getQuestions();
        req.setAttribute("questions", questions);
        req.getRequestDispatcher("quiz.jsp").forward(req, resp);
    }
}
