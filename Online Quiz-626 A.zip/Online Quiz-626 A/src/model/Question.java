package model;

public class Question {
    private String text;
    private String[] options;
    private int correctIndex;

    public Question(String text, String optA, String optB, String optC, String optD, int correctIndex) {
        this.text = text;
        this.options = new String[]{optA, optB, optC, optD};
        this.correctIndex = correctIndex;
    }

    public String getText() {
        return text;
    }

    public String[] getOptions() {
        return options;
    }

    public int getCorrectIndex() {
        return correctIndex;
    }
}
