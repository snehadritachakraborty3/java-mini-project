package data;

import model.Question;
import java.util.ArrayList;
import java.util.List;

public class QuestionBank {
    public static List<Question> getQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(new Question(
            "Which keyword is used to inherit a class in Java?",
            "super", "import", "extends", "implements", 2
        ));
        list.add(new Question(
            "Which of these is NOT a primitive data type?",
            "int", "boolean", "String", "float", 2
        ));
        list.add(new Question(
            "Java code is compiled into:",
            "Bytecode", "Machine code", "Python script", "Assembly", 0
        ));
        list.add(new Question(
            "Which symbol ends a Java statement?",
            ".", ":", ";", ",", 2
        ));
        list.add(new Question(
            "Which keyword defines a class in Java?",
            "class", "struct", "define", "object", 0
        ));

        return list;
    }
}
